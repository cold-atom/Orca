# Orca

Orca is a safety-first AI development assistant integrated into the Godot editor.

This directory is the complete installable Orca 1.0.0 addon for Godot 4.7.2.

## Install

1. Copy `addons/orca/` into your Godot project's `addons/` directory.
2. Open the project in Godot 4.7.2.
3. Enable **Orca** in **Project > Project Settings > Plugins**.
4. Open the Orca dock, select a provider, add your API key, and choose a model.

## Safety Model

- Plan mode is read-only.
- Work mode can prepare changes, but every model-requested project change requires explicit approval.
- File proposals use content hashes, validation, stale-state checks, and guarded revert data.
- Project access, tool output, network inactivity, and Orca-owned game processes are bounded.

Always review proposed changes and use source control. Orca does not replace code review, backups, or project testing.

## Providers And Data

Orca supports OpenAI, Google Gemini, xAI, DeepSeek, OpenRouter, and custom OpenAI-compatible endpoints through its current Chat Completions transport.

Prompts, relevant editor context, and project content returned by Orca's tools may be sent to the selected provider. API credentials are saved through Godot Editor Settings, and project-scoped session history is stored as plaintext JSON under Godot's `user://` storage. Neither is an encrypted OS credential store.

## License

Orca source code is distributed under the MIT License included in this directory. Bundled third-party assets may carry their own license terms and attribution requirements.
